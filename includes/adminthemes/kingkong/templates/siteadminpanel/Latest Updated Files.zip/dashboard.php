<?php  
$p_info=$db->getRowArray('admin',state('AR_admin_id')); 
?>
<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12">
		<div class="panel panel-info">
			<div class="panel-heading">
			  <h3 class="panel-title">Dashboard</h3>
			</div>
			<div class="panel-body">
				 <div class="row">
					<div class="col-md-5 col-sm-12 col-xs-12">					
							<h2><?=$p_info['fname']?> <?=$p_info['lname']?></h2>
							<h2><i class="fa fa-envelope"></i> <?=$p_info['admin_email']?> &nbsp; <i class="fa fa-phone"></i> <?=$p_info['admin_phone']?></h2>		
					
                    
                    <br />
                    <br />
                    <a href="<?=ADMIN_URL?>addQuote" class="btn btn-danger btn-large">Add Quote</a>
                    <br />
                    <br />
                    </div>
					
					<div class="col-md-7 col-sm-12 col-xs-12">
					   <div class="panel panel-success">
								<div class="panel-heading">
								  <h3 class="panel-title">Site Statistics Board!</h3>
								</div>
								<div class="panel-body">					
						<?php
                        
  
                        //PO_ORDER   
                        	$todays_poorders= number_format($db->affected("SELECT client_history_id FROM `client_history` WHERE `history_type` ='po_order' AND date(`date_added`) ='".date("Y-m-d")."'"));
                        	$yesterday_poorders= number_format($db->affected("SELECT client_history_id FROM `client_history` WHERE `history_type` ='po_order' AND date(`date_added`) ='".date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d")-1, date("Y")))."'"));                  
                        	$lastweek_poorders= number_format($db->affected("SELECT client_history_id FROM `client_history` WHERE `history_type` ='po_order' AND date(`date_added`) between '". date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d")-6, date("Y")))."' AND '".date("Y-m-d")."'"));                  
                        	$lastmonth_poorders=number_format($db->affected("SELECT client_history_id FROM `client_history` WHERE `history_type` ='po_order' AND date(`date_added`) between '". date("Y-m-d",mktime(0, 0, 0, date("m")-1  , date("d"), date("Y")))."' AND '".date("Y-m-d")."'"));
                        	$lastyear_poorders= number_format($db->affected("SELECT client_history_id FROM `client_history` WHERE `history_type` ='po_order' AND date(`date_added`) between '". date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d"), date("Y")-1))."' AND '".date("Y-m-d")."'"));
                        	$total_poorders= number_format($db->affected("SELECT client_history_id FROM `client_history` WHERE `history_type` ='po_order'")); 


                        //Client Visit
                        	$todays_clientVisit= number_format($db->affected("SELECT client_history_id FROM `client_history` WHERE `history_type` ='client_visit' AND date(`date_added`) ='".date("Y-m-d")."'"));
                        	$yesterday_clientVisit= number_format($db->affected("SELECT client_history_id FROM `client_history` WHERE `history_type` ='client_visit' AND date(`date_added`) ='".date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d")-1, date("Y")))."'"));                  
                        	$lastweek_clientVisit= number_format($db->affected("SELECT client_history_id FROM `client_history` WHERE `history_type` ='client_visit' AND date(`date_added`) between '". date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d")-6, date("Y")))."' AND '".date("Y-m-d")."'"));                  
                        	$lastmonth_clientVisit=number_format($db->affected("SELECT client_history_id FROM `client_history` WHERE `history_type` ='client_visit' AND date(`date_added`) between '". date("Y-m-d",mktime(0, 0, 0, date("m")-1  , date("d"), date("Y")))."' AND '".date("Y-m-d")."'"));
                        	$lastyear_clientVisit= number_format($db->affected("SELECT client_history_id FROM `client_history` WHERE `history_type` ='client_visit' AND date(`date_added`) between '". date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d"), date("Y")-1))."' AND '".date("Y-m-d")."'"));
                        	$total_clientVisit= number_format($db->affected("SELECT client_history_id FROM `client_history` WHERE `history_type` ='client_visit'")); 


                        //client Followup
                        	$todays_clientFollowUP= number_format($db->affected("SELECT client_history_id FROM `client_history` WHERE `history_type` ='client_followup' AND date(`date_added`) ='".date("Y-m-d")."'"));
                        	$yesterday_clientFollowUP= number_format($db->affected("SELECT client_history_id FROM `client_history` WHERE `history_type` ='client_followup' AND date(`date_added`) ='".date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d")-1, date("Y")))."'"));                  
                        	$lastweek_clientFollowUP= number_format($db->affected("SELECT client_history_id FROM `client_history` WHERE `history_type` ='client_followup' AND date(`date_added`) between '". date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d")-6, date("Y")))."' AND '".date("Y-m-d")."'"));                  
                        	$lastmonth_clientFollowUP=number_format($db->affected("SELECT client_history_id FROM `client_history` WHERE `history_type` ='client_followup' AND date(`date_added`) between '". date("Y-m-d",mktime(0, 0, 0, date("m")-1  , date("d"), date("Y")))."' AND '".date("Y-m-d")."'"));
                        	$lastyear_clientFollowUP= number_format($db->affected("SELECT client_history_id FROM `client_history` WHERE `history_type` ='client_followup' AND date(`date_added`) between '". date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d"), date("Y")-1))."' AND '".date("Y-m-d")."'"));
                        	$total_clientFollowUP= number_format($db->affected("SELECT client_history_id FROM `client_history` WHERE `history_type` ='client_followup'")); 

                        //offer_letter
                        	$todays_clientOfferLetter= number_format($db->affected("SELECT client_history_id FROM `client_history` WHERE `history_type` ='offer_letter' AND date(`date_added`) ='".date("Y-m-d")."'"));
                        	$yesterday_clientOfferLetter= number_format($db->affected("SELECT client_history_id FROM `client_history` WHERE `history_type` ='offer_letter' AND date(`date_added`) ='".date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d")-1, date("Y")))."'"));                  
                        	$lastweek_clientOfferLetter= number_format($db->affected("SELECT client_history_id FROM `client_history` WHERE `history_type` ='offer_letter' AND date(`date_added`) between '". date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d")-6, date("Y")))."' AND '".date("Y-m-d")."'"));                  
                        	$lastmonth_clientOfferLetter=number_format($db->affected("SELECT client_history_id FROM `client_history` WHERE `history_type` ='offer_letter' AND date(`date_added`) between '". date("Y-m-d",mktime(0, 0, 0, date("m")-1  , date("d"), date("Y")))."' AND '".date("Y-m-d")."'"));
                        	$lastyear_clientOfferLetter= number_format($db->affected("SELECT client_history_id FROM `client_history` WHERE `history_type` ='offer_letter' AND date(`date_added`) between '". date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d"), date("Y")-1))."' AND '".date("Y-m-d")."'"));
                        	$total_clientOfferLetter= number_format($db->affected("SELECT client_history_id FROM `client_history` WHERE `history_type` ='offer_letter'")); 

                        //Clients
                        	$todays_clientLeads= number_format($db->affected("SELECT client_id FROM `clients` WHERE date(`date_added`) ='".date("Y-m-d")."'"));
                        	$yesterday_clientLeads= number_format($db->affected("SELECT client_id FROM `clients` WHERE date(`date_added`) ='".date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d")-1, date("Y")))."'"));                  
                        	$lastweek_clientLeads= number_format($db->affected("SELECT client_id FROM `clients` WHERE date(`date_added`) between '". date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d")-6, date("Y")))."' AND '".date("Y-m-d")."'"));                  
                        	$lastmonth_clientLeads=number_format($db->affected("SELECT client_id FROM `clients` WHERE date(`date_added`) between '". date("Y-m-d",mktime(0, 0, 0, date("m")-1  , date("d"), date("Y")))."' AND '".date("Y-m-d")."'"));
                        	$lastyear_clientLeads= number_format($db->affected("SELECT client_id FROM `clients` WHERE date(`date_added`) between '". date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d"), date("Y")-1))."' AND '".date("Y-m-d")."'"));
                        	$total_clientLeads= number_format($db->affected("SELECT client_id FROM `clients`")); 



/**
		 * 	//USERS
		 * 						$todays_user= number_format($db->affected("SELECT author_id FROM `users` WHERE date(`user_created`) ='".date("Y-m-d")."'"));
		 * 						$yesterday_user= number_format($db->affected("SELECT user_id FROM `users` WHERE date(`user_created`) ='".date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d")-1, date("Y")))."'"));                  
		 * 						$lastweek_user= number_format($db->affected("SELECT user_id FROM `users` WHERE date(`user_created`) between '". date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d")-6, date("Y")))."' AND '".date("Y-m-d")."'"));                  
		 * 						$lastmonth_user=number_format($db->affected("SELECT user_id FROM `users` WHERE date(`user_created`) between '". date("Y-m-d",mktime(0, 0, 0, date("m")-1  , date("d"), date("Y")))."' AND '".date("Y-m-d")."'"));
		 * 						$lastyear_user= number_format($db->affected("SELECT user_id FROM `users` WHERE date(`user_created`) between '". date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d"), date("Y")-1))."' AND '".date("Y-m-d")."'"));
		 * 						$total_user= number_format($db->affected("SELECT user_id FROM `users`")); 
		 * 						$total_online_users= number_format($db->affected("SELECT user_id FROM `users` WHERE login = 1")); 
		 * 				
		 */		?>
								
										<table class="table table-bordered" border="0" cellpadding="0" cellspacing="1">
										<thead class="dload-th">
										<tr>
											<td class="tf">&nbsp;</td>			            
											<td class="tc">Today</td>
											<td class="tc">Yesterday</td>
											<td class="tc">Last week</td>
											<td class="tc">Last month</td>
											<td class="tc">Last year</td>
											<td class="last">Total</td>
										 </tr>
										</thead>
										
										<tbody class="dload-tb"> 
                                        
                                        <tr class="bg1">
                                			<td class="tf"><b>PO Order/Signup</b></td>	    
                                			<td class="tc"><?=$todays_poorders?></td>
                                			<td class="tc"><?=$yesterday_poorders?></td>
                                			<td class="tc"><?=$lastweek_poorders?></td>
                                			<td class="tc"><?=$lastmonth_poorders?></td>
                                			<td class="tc"><?=$lastyear_poorders?></td>
                                			<td class="last"><?=$total_poorders?></td>
                                		</tr>

                                		 <tr class="bg1">
                                			<td class="tf"><b>Client Visit</b></td>			            
                                			<td class="tc"><?=$todays_clientVisit?></td>
                                			<td class="tc"><?=$yesterday_clientVisit?></td>
                                			<td class="tc"><?=$lastweek_clientVisit?></td>
                                			<td class="tc"><?=$lastmonth_clientVisit?></td>
                                			<td class="tc"><?=$lastyear_clientVisit?></td>
                                			<td class="last"><?=$total_clientVisit?></td>
                                		</tr>

                                		<tr class="bg1">
                                			<td class="tf"><b>Client FollowUp</b></td>			            
                                			<td class="tc"><?=$todays_clientFollowUP?></td>
                                			<td class="tc"><?=$yesterday_clientFollowUP?></td>
                                			<td class="tc"><?=$lastweek_clientFollowUP?></td>
                                			<td class="tc"><?=$lastmonth_clientFollowUP?></td>
                                			<td class="tc"><?=$lastyear_clientFollowUP?></td>
                                			<td class="last"><?=$total_clientFollowUP?></td>
                                		</tr>

                                		<tr class="bg1">
                                			<td class="tf"><b>Offer Letter</b></td>	       
                                			<td class="tc"><?=$todays_clientOfferLetter?></td>
                                			<td class="tc"><?=$yesterday_clientOfferLetter?></td>
                                			<td class="tc"><?=$lastweek_clientOfferLetter?></td>
                                			<td class="tc"><?=$lastmonth_clientOfferLetter?></td>
                                			<td class="tc"><?=$lastyear_clientOfferLetter?></td>
                                			<td class="last"><?=$total_clientOfferLetter?></td>
                                		</tr>

                                		<tr class="bg1">
                                			<td class="tf"><b>Leads</b></td>			            
                                			<td class="tc"><?=$todays_clientLeads?></td>
                                			<td class="tc"><?=$yesterday_clientLeads?></td>
                                			<td class="tc"><?=$lastweek_clientLeads?></td>
                                			<td class="tc"><?=$lastmonth_clientLeads?></td>
                                			<td class="tc"><?=$lastyear_clientLeads?></td>
                                			<td class="last"><?=$total_clientLeads?></td>
                                		</tr>
        
                                        
										 <?php /*?> 	<tr class="bg2">
												<td class="tf"><b>Authors</b></td>			            
												<td class="tc"><?=$todays_user?></td>
												<td class="tc"><?=$yesterday_user?></td>
												<td class="tc"><?=$lastweek_user?></td>
												<td class="tc"><?=$lastmonth_user?></td>
												<td class="tc"><?=$lastyear_user?></td>
												<td class="last"><?=$total_user?></td>
											</tr> <?php */?> 
										</tbody>
									</table> 
                                    
                                  
							</div><!--panel-body-->


							<div class="panel-heading">
								  <h3 class="panel-title">PO/Signup Statistics Board!</h3>
							</div>


					<div class="panel-body">
					<?php  
						//Todays
							$todays_Amount= $db->select_single("SELECT SUM(`po_otc_amount`) AS otcAmount, SUM(`po_mrc_amount`) AS mrcAmount, SUM(`po_yrc_amount`) AS yrcAmount, SUM(`po_total_amount`) AS totalAmount FROM `client_history` WHERE date(`date_added`) ='".date("Y-m-d")."'");
						//Yeasterday
							$yesterday_Amount= $db->select_single("SELECT SUM(po_otc_amount) AS otcAmount, SUM(po_mrc_amount) AS mrcAmount, SUM(po_yrc_amount) AS yrcAmount, SUM(po_total_amount) AS totalAmount FROM `client_history` WHERE date(`date_added`) ='".date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d")-1, date("Y")))."'");  
						//last week
							$lastweek_Amount= $db->select_single("SELECT SUM(po_otc_amount) AS otcAmount, SUM(po_mrc_amount) AS mrcAmount, SUM(po_yrc_amount) AS yrcAmount, SUM(po_total_amount) AS totalAmount FROM `client_history` WHERE date(`date_added`) between '". date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d")-6, date("Y")))."' AND '".date("Y-m-d")."'"); 

                        //last month
                        
                            $lastmonth_Amount=$db->select_single("SELECT SUM(po_otc_amount) AS otcAmount, SUM(po_mrc_amount) AS mrcAmount, SUM(po_yrc_amount) AS yrcAmount, SUM(po_total_amount) AS totalAmount FROM `client_history` WHERE date(`date_added`) between '". date("Y-m-d",mktime(0, 0, 0, date("m")-1  , date("d"), date("Y")))."' AND '".date("Y-m-d")."'");

						//last Year
							$lastyear_Amount= $db->select_single("SELECT SUM(po_otc_amount) AS otcAmount, SUM(po_mrc_amount) AS mrcAmount, SUM(po_yrc_amount) AS yrcAmount, SUM(po_total_amount) AS totalAmount FROM `client_history` WHERE date(`date_added`) between '". date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d"), date("Y")-1))."' AND '".date("Y-m-d")."'");
						//Total
							$total_Amount= $db->select_single("SELECT SUM(po_otc_amount) AS otcAmount, SUM(po_mrc_amount) AS mrcAmount, SUM(po_yrc_amount) AS yrcAmount, SUM(po_total_amount) AS totalAmount  FROM `client_history`");
					?>

									<table class="table table-bordered" border="0" cellpadding="0" cellspacing="1">
										<thead class="dload-th">
											<tr>
												<td class="tf">&nbsp;</td>			            
												<td class="tc">OTC Amount</td>
												<td class="tc">MRC Amount</td>
												<td class="tc">YRC Amount</td>
												<td class="tc">Total Amount</td>
										  </tr>
										</thead>

										<tbody class="dload-tb"> 
                                        <tr class="bg1">
                                			<td class="tf"><b>Today</b></td>
                                			<td class="tc"><?=$todays_Amount['otcAmount']?></td>
                                			<td class="tc"><?=$todays_Amount['mrcAmount']?></td>
                                			<td class="tc"><?=$todays_Amount['yrcAmount']?></td>
                                			<td class="tc"><?=$todays_Amount['totalAmount']?></td>
                                		</tr>

                                		<tr class="bg1">
                                			<td class="tf"><b>Yeasterday</b></td>	
                                			<td class="tc"><?=$yesterday_Amount['otcAmount']?></td>	
                                			<td class="tc"><?=$yesterday_Amount['mrcAmount']?></td>	
                                			<td class="tc"><?=$yesterday_Amount['yrcAmount']?></td>	
                                			<td class="tc"><?=$yesterday_Amount['totalAmount']?></td>	
                                		</tr>

                                		<tr class="bg1">
                                			<td class="tf"><b>Last Week</b></td>	
                                			<td class="tc"><?=$lastweek_Amount['otcAmount']?></td>	
                                			<td class="tc"><?=$lastweek_Amount['mrcAmount']?></td>	
                                			<td class="tc"><?=$lastweek_Amount['yrcAmount']?></td>	
                                			<td class="tc"><?=$lastweek_Amount['totalAmount']?></td>	
                                		</tr>

                                        <tr class="bg1">
                                            <td class="tf"><b>Last Month</b></td>    
                                            <td class="tc"><?=$lastmonth_Amount['otcAmount']?></td>  
                                            <td class="tc"><?=$lastmonth_Amount['mrcAmount']?></td>  
                                            <td class="tc"><?=$lastmonth_Amount['yrcAmount']?></td>  
                                            <td class="tc"><?=$lastmonth_Amount['totalAmount']?></td>    
                                        </tr>

                                		<tr class="bg1">
                                			<td class="tf"><b>Last Year</b></td>	
                                			<td class="tc"><?=$lastyear_Amount['otcAmount']?></td>	
                                			<td class="tc"><?=$lastyear_Amount['mrcAmount']?></td>	
                                			<td class="tc"><?=$lastyear_Amount['yrcAmount']?></td>	
                                			<td class="tc"><?=$lastyear_Amount['totalAmount']?></td>	
                                		</tr>

                                		<tr class="bg1">
                                			<td class="tf"><b>Total</b></td>	
                                			<td class="tc"><?=$total_Amount['otcAmount']?></td>	
                                			<td class="tc"><?=$total_Amount['mrcAmount']?></td>	
                                			<td class="tc"><?=$total_Amount['yrcAmount']?></td>	
                                			<td class="tc"><?=$total_Amount['totalAmount']?></td>	
                                		</tr>
										</tbody>
									</table> 
								</div>
						   </div>									
						</div>	
				</div>
			</div><!--panel-body-->
	   </div>   
	</div>
</div><!--row-->
<?php //include('dashboard_statistic_graph.php');?>	
