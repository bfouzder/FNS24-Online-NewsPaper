
<?php

print"

<html>

<head>

<script language='javascript'>


function a()

{

alert( 'Write correct ! ');



}

</script>


</head>

<body onload='a()'>

</body>

</html>


";
?>