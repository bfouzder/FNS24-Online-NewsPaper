
<?php

print"

<html>

<head>

<script language='javascript'>


function a()

{

alert( ' Something wrong please select correct  Ledger and Expense Name ');

}

</script>


</head>

<body onload='a()'>

</body>

</html>


";
?>