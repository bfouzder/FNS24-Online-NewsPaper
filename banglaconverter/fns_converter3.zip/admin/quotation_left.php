<?php
print"
<tr> <td height='30' width='200' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" align='left' id='button2'>  <a href='challan_q.php'> <div id='child'> Quotation Invoice </div> </a> </td></tr>

<tr> <td height='7'> </td></tr>
";





print"
<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='challan_view_q.php' target='_blank'><div id='child'> All Quotation View  </div> </a> </td></tr>
<tr> <td height='7'> </td></tr>
";







print"
</table>


</td>
";

?>