
<?php

print"

<html>

<head>

<script language='javascript'>


function a()

{

alert( ' Success your saving ');

}

</script>


</head>

<body onload='a()'>

</body>

</html>


";
?>