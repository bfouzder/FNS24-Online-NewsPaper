
<?php

print"

<html>

<head>

<script language='javascript'>


function a()

{

alert( ' Not Save exist write another product id ');

}

</script>


</head>

<body onload='a()'>

</body>

</html>


";
?>