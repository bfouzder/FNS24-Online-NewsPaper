<?php
include_once('dbconnection.php');






print"

<html>

<head>
<title> Help Line - 01686797756  </title>
";


include_once('style.php');


print"
</head>


<body>
";


include_once('header.php');


print"
<table align='center' width='1200' cellpadding='0' cellspacing='1' height='800' bgcolor='gray'>
<tr bgcolor='white'> 
<td align='center' valign='top' width='220' bgcolor='#C5B991'>  

<table align='center' width='200' cellpadding='0' cellspacing='0' height=''>

<tr> <td height='10'> </td></tr>


<tr> <td height='30' width='200' bgcolor='green'> &nbsp;&nbsp;&nbsp;  <span id='child'> <b> <font color='white'>Create</font> </b> </span>  </td></tr>

<tr> <td height='7'> </td></tr>





";


include_once('create_left.php');


print"

<td align='center' valign='top' width='980'>  




<br>
<br>



<table align='center' width='900'' cellpadding='0' cellspacing='0'>


<tr> <td align='left'> <FONT FACE='ARIAL' SIZE='6'> <B> Dynamic Business  Solution Software </B> </FONT> </td> </tr>


<tr> <td align='left'> <FONT FACE='ARIAL' SIZE='2'> <B> Mobile: 01686797756, 01722436067   </B> </FONT> </td> </tr>


<tr> <td align='left' height='35'>  <FONT FACE='ARIAL' SIZE='5'> <B>    আমাদের  Software-এর সুযোগ সুবিধা সমূহ    </B> </FONT> </td> </tr>





</table>





<br>



<table align='center' width='900'' cellpadding='0' cellspacing='0'>







<tr> <td align='left' height='35'> *** <FONT FACE='ARIAL' SIZE='4'> <B>  <u> Bill / Challan / Quotation / Money Receipt করেত পারবেন  .  </u></B> </FONT> </td> </tr>
<tr> <td align='left' height='35'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u> Debit Voucher / Credit Voucher  করেত পারবেন  .  </u></B> </FONT> </td> </tr>

<tr> <td align='left' height='35'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u> Direct / Bill To Bill Collection  করেত পারবেন  .  </u></B> </FONT> </td> </tr>


<tr> <td align='left' height='35'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u> Daily / monthly / Yearly Sales Report . </u></B> </FONT> </td> </tr>
<tr> <td align='left' height='35'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u> Daily / monthly / Yearly Purchase Report . </u></B> </FONT> </td> </tr>


<tr> <td align='left' height='35'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u> Daily / monthly / Yearly Cash Sales / Due Sales Report . </u></B> </FONT> </td> </tr>

<tr> <td align='left' height='35'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u> Daily / monthly / Yearly খরচের  Report . </u></B> </FONT> </td> </tr>
 


<tr> <td align='left' height='35'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u> Daily / monthly / Yearly Product Stock  Report . </u></B> </FONT> </td> </tr>


<tr> <td align='left' height='35'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u> Daily / monthly / Yearly Party Wise Sales  Report . </u></B> </FONT> </td> </tr>

<tr> <td align='left' height='35'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u> Daily / monthly / Yearly Party Wise Purchase  Report . </u></B> </FONT> </td> </tr>



<tr> <td align='left' height='35'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u> Daily / monthly / Yearly Party Ledger Report . </u></B> </FONT> </td> </tr> 
<tr> <td align='left' height='35'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u> Daily / monthly / Yearly Party Due Report . </u></B> </FONT> </td> </tr>

 <tr> <td align='left' height='35'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u> Daily / monthly / Yearly Cash Book Report . </u></B> </FONT> </td> </tr>

 
 <tr> <td align='left' height='35'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u> Daily / monthly / Yearly Bank Balance Report . </u></B> </FONT> </td> </tr>
 
 <tr> <td align='left' height='35'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u> Daily / monthly / Yearly Discount Report . </u></B> </FONT> </td> </tr>
 
 
  <tr> <td align='left' height='35'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u> Daily / monthly / Yearly Product Wise Profit Report . </u> </B> </FONT> </td> </tr>
 
   <tr> <td align='left' height='35'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u> Daily / monthly / Yearly Party Wise Profit Report . </u> </B> </FONT> </td> </tr>
 
 <tr> <td align='left' height='35'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u> Daily / monthly / Yearly Profit Report . </u> </B> </FONT> </td> </tr>
 
 
 
 
 
</table>






<br><br>

<table align='center' width='900'' cellpadding='0' cellspacing='0'>
<tr> <td align='left'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u> কিভাবে  Product Name Entry  করবেন  ?</u></B> </FONT> </td> </tr>


<tr> <td height='10'> </td> </tr>

<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Create option-এ click  করবেন </B> </FONT> </td> </tr>
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Product Category Entry  করবেন </B> </FONT> </td> </tr>
 
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Product Sub Category Entry  করবেন </B> </FONT> </td> </tr>

<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Product Name Entry  করবেন </B> </FONT> </td> </tr>
 
</table>




<br>


<table align='center' width='900'' cellpadding='0' cellspacing='0'>
<tr> <td align='left'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u> কিভাবে  Product Name Edit / Delete  করবেন  ?</u></B> </FONT> </td> </tr>
<tr> <td height='10'> </td> </tr>
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Edit option-এ click  করবেন </B> </FONT> </td> </tr>

<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Product Category Edit  করবেন </B> </FONT> </td> </tr>
 
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Product Sub Category Edit  করবেন </B> </FONT> </td> </tr>
 
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Product Name Edit  করবেন </B> </FONT> </td> </tr>
 
</table>















<br>


<table align='center' width='900'' cellpadding='0' cellspacing='0'>
<tr> <td align='left'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u>  যাদের কাছ থেকে  Product কিনে আনবেন তাদের নাম / Ledger Entry করবেন  কিভাবে  ?</u></B> </FONT> </td> </tr>

<tr> <td height='10'> </td> </tr>

<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Create option-এ click  করবেন </B> </FONT> </td> </tr>


<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B>  Supplier Name Entry করবেন </B> </FONT> </td> </tr>
 


 
 <tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3' color='red'> <B> ভুল হলে  Edit option-এ click  করবেন </B> </FONT> </td> </tr>

 
 <tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3' color='red'> <B>  Supplier Name Edit  করবেন </B> </FONT> </td> </tr>
 
</table>













<br>


<table align='center' width='900'' cellpadding='0' cellspacing='0'>
<tr> <td align='left'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u> কিভাবে  Product Purchase / ক্রয়   করবেন  ?</u></B> </FONT> </td> </tr>
<tr> <td height='10'> </td> </tr>
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Purchase option-এ click  করবেন </B> </FONT> </td> </tr>

<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Party And Date Select   করবেন </B> </FONT> </td> </tr>
 
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Product add    করবেন </B> </FONT> </td> </tr>
 
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Final করে  Save And Print Buttony Click করবেন   একটি প্রিন্ট কপি বের হবে</B> </FONT> </td> </tr>
 
 
  <tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3' color='red'> <B> ভুল হলে  Edit / Delete করা যাবে  </B> </FONT> </td> </tr>

</table>















<br>


<table align='center' width='900'' cellpadding='0' cellspacing='0'>
<tr> <td align='left'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u>  যাদের কাছে   Product বিক্রয়  করবেন  তাদের নাম / Ledger Entry করবেন  কিভাবে  ?</u></B> </FONT> </td> </tr>

<tr> <td height='10'> </td> </tr>

<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Create option-এ click  করবেন </B> </FONT> </td> </tr>


<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B>  Customer Name Entry করবেন </B> </FONT> </td> </tr>
 


 
 <tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3' color='red'> <B> ভুল হলে  Edit option-এ click  করবেন </B> </FONT> </td> </tr>

 
 <tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3' color='red'> <B>  Customer Name Edit  করবেন </B> </FONT> </td> </tr>
 
</table>















<br>
<table align='center' width='900'' cellpadding='0' cellspacing='0'>
<tr> <td align='left'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u> কিভাবে  Product Sale / বিক্রয়   করবেন  ?</u></B> </FONT> </td> </tr>
<tr> <td height='10'> </td> </tr>
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B>  Sales option-এ click  করবেন </B> </FONT> </td> </tr>

<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Customer And Date Select   করবেন </B> </FONT> </td> </tr>
 
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Product add    করবেন    (  With Barcode ) </B> </FONT> </td> </tr>


<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Discount add করা যাবে </B> </FONT> </td> </tr>
  
 
 
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Final করে  Save And Print Buttony Click করবেন   একটি  Bill প্রিন্ট কপি বের হবে</B> </FONT> </td> </tr>
 
 
  <tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3' color='red'> <B> ভুল হলে  Edit / Delete করা যাবে  </B> </FONT> </td> </tr>

</table>










<br>


<table align='center' width='900'' cellpadding='0' cellspacing='0'>
<tr> <td align='left'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u> কিভাবে   খরচ  Entry করবেন  ?</u></B> </FONT> </td> </tr>
<tr> <td height='10'> </td> </tr>
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Cost Entry option-এ click  করবেন </B> </FONT> </td> </tr

<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Cost Name And Date Select   করবেন </B> </FONT> </td> </tr>
 
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Amount লিখবেন  </B> </FONT> </td> </tr>
 
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Final করে  Save And Print Buttony Click করবেন   একটি প্রিন্ট কপি বের হবে</B> </FONT> </td> </tr>
 
 
  <tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3' color='red'> <B> ভুল হলে  Edit / Delete করা যাবে  </B> </FONT> </td> </tr>

</table>













<br>


<table align='center' width='900'' cellpadding='0' cellspacing='0'>
<tr> <td align='left'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u> কিভাবে   Money Receipt  করবেন  ?</u></B> </FONT> </td> </tr>
<tr> <td height='10'> </td> </tr>
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Collection option-এ click  করবেন </B> </FONT> </td> </tr

<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Customer Name And Date Select   করবেন </B> </FONT> </td> </tr>
 
 
 
 
 
 
 <tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B>  Search Optiony  Click   করবেন </B> </FONT> </td> </tr>
 
 
 
 
 
 
 
 
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Amount লিখবেন  </B> </FONT> </td> </tr>
 
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Final করে  Save And Print Buttony Click করবেন   একটি প্রিন্ট কপি বের হবে</B> </FONT> </td> </tr>
 
 
  <tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3' color='red'> <B> ভুল হলে  Edit / Delete করা যাবে  </B> </FONT> </td> </tr>

</table>











<br>
<table align='center' width='900'' cellpadding='0' cellspacing='0'>
<tr> <td align='left'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u> কিভাবে   Bank Name  Entry করবেন  ?</u></B> </FONT> </td> </tr>
<tr> <td height='10'> </td> </tr>
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Create option-এ click  করবেন </B> </FONT> </td> </tr

<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Bank Name Click   করবেন </B> </FONT> </td> </tr>
 
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B>Bank  Name / Account No. Address  লিখবেন  </B> </FONT> </td> </tr>
 
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Final করে  Save  Buttony Click করবেন  </B> </FONT> </td> </tr>
 
 
  <tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3' color='red'> <B> ভুল হলে  Edit Optiony Click করবেন   </B> </FONT> </td> </tr>
</table>
















<br>
<table align='center' width='900'' cellpadding='0' cellspacing='0'>
<tr> <td align='left'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u> কিভাবে   Opening Balance  Entry করবেন  ?</u></B> </FONT> </td> </tr>
<tr> <td height='10'> </td> </tr>
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Opening Balance option-এ click  করবেন </B> </FONT> </td> </tr

<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Customer-এ Click   করবেন </B> </FONT> </td> </tr>
 
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Supplier-এ Click   করবেন  </B> </FONT> </td> </tr>
 
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Bank Name-এ Click   করবেন  </B> </FONT> </td> </tr>


<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Cash Book-এ Click   করবেন  </B> </FONT> </td> </tr>
 

 
 
  <tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3' color='red'> <B> ভুল হলে  Edit / Delete করা যাবে   </B> </FONT> </td> </tr>
</table>


















<br>









<table align='center' width='900'' cellpadding='0' cellspacing='0'>
<tr> <td align='left'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u> কিভাবে   Customer Ledger Transaction বের করবেন  ?</u></B> </FONT> </td> </tr>
<tr> <td height='10'> </td> </tr>
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Find Transation option-এ click  করবেন </B> </FONT> </td> </tr

<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Customer Ledger Click   করবেন </B> </FONT> </td> </tr>
 
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Customer And Date Select করে  Search করবেন  তার লেজার  Transaction  বের হবে </B> </FONT> </td> </tr>
 

</table>







<br>


<table align='center' width='900'' cellpadding='0' cellspacing='0'>
<tr> <td align='left'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u> কিভাবে   Supplier Ledger Transaction বের করবেন  ?</u></B> </FONT> </td> </tr>
<tr> <td height='10'> </td> </tr>
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Find Transation option-এ click  করবেন </B> </FONT> </td> </tr

<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Supplier Ledger Click   করবেন </B> </FONT> </td> </tr>
 
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Supplier And Date Select করে  Search করবেন  তার লেজার  Transaction  বের হবে </B> </FONT> </td> </tr>
 

</table>



<br>


<table align='center' width='900'' cellpadding='0' cellspacing='0'>
<tr> <td align='left'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u> কিভাবে   Bank Ledger Transaction বের করবেন  ?</u></B> </FONT> </td> </tr>
<tr> <td height='10'> </td> </tr>
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Find Transation option-এ click  করবেন </B> </FONT> </td> </tr

<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Bank Ledger Click   করবেন </B> </FONT> </td> </tr>
 
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Bank Name And Date Select করে  Search করবেন  তার লেজার  Transaction  বের হবে </B> </FONT> </td> </tr>
 

</table>










<br>


<table align='center' width='900'' cellpadding='0' cellspacing='0'>
<tr> <td align='left'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u> কিভাবে   Customer Due List বের করবেন  ?</u></B> </FONT> </td> </tr>
<tr> <td height='10'> </td> </tr>
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Find Due option-এ click  করবেন </B> </FONT> </td> </tr

<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Customer Due Click  করবেন  Due List বের  হবে </B> </FONT> </td> </tr>
 

</table>



<br>


<table align='center' width='900'' cellpadding='0' cellspacing='0'>
<tr> <td align='left'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u> কিভাবে   Stock Report  বের করবেন  ?</u></B> </FONT> </td> </tr>
<tr> <td height='10'> </td> </tr>
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Inventory option-এ click  করবেন </B> </FONT> </td> </tr

<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Product Stock List  বের  হবে </B> </FONT> </td> </tr>
 
</table>





<br>


<table align='center' width='900'' cellpadding='0' cellspacing='0'>
<tr> <td align='left'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u> কিভাবে   Cash Book  বের করবেন  ?</u></B> </FONT> </td> </tr>
<tr> <td height='10'> </td> </tr>
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Cash Book option-এ click  করবেন </B> </FONT> </td> </tr>

</table>



<br>


<table align='center' width='900'' cellpadding='0' cellspacing='0'>
<tr> <td align='left'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u> কিভাবে   বিভিন্ন  Report  বের করবেন  ?</u></B> </FONT> </td> </tr>
<tr> <td height='10'> </td> </tr>
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Report option-এ click  করবেন </B> </FONT> </td> </tr>

 
 
 
 <tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B>   বাম  পাশে   সকল  Option আছে যে যে  Report বের  করবেন  তার উপর  Click  করবেন</B> </FONT> </td> </tr>

 
</table>

















<br>


<table align='center' width='900'' cellpadding='0' cellspacing='0'>
<tr> <td align='left'> *** <FONT FACE='ARIAL' SIZE='4'> <B> <u> কিভাবে   আপনার  Business Capital  বের করবেন  ?</u></B> </FONT> </td> </tr>
<tr> <td height='10'> </td> </tr>
<tr> <td align='left' height='30'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 >> <FONT FACE='ARIAL' SIZE='3'> <B> Profit & Loss Optiony Click করবেন </B> </FONT> </td> </tr>


 
</table>






























</td>


</tr>
</table>




</body>

</html>


";


?>