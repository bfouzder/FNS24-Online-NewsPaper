<?php
include_once('dbconnection.php');
print"

<html>

<head>
<title> Check report  </title>
";


include_once('style.php');


print"
</head>


<body>
";


include_once('header.php');


print"
<table align='center' width='1200' cellpadding='0' cellspacing='1' height='800' bgcolor='gray'>
<tr bgcolor='white'> 

";





include_once('check_report_left.php');






print"
<td align='center' valign='top' width='980'>  </td>

</tr>
</table>




</body>

</html>


";


?>