<?php

if($cwp1==1)
{
print"
 <td width='70' align='center'><font face='arial' size='4'> <b> $cwp11  </b> </font> </td> 
";
}

if($cwp2==1)
{
print"
 <td width='70' align='center'><font face='arial' size='4'> <b> $cwp22 </b> </font> </td> 
";
}

if($cwp3==1)
{
print"
 <td width='70' align='center'><font face='arial' size='4'> <b> $cwp33 </b> </font> </td> 
";
}

if($cwp4==1)
{
print"
 <td width='70' align='center'><font face='arial' size='4'> <b> $cwp44 </b> </font> </td> 
";
}
?>