
<?php

print"

<html>

<head>

<script language='javascript'>


function a()

{

alert( ' Success your saving ');
window.close();
window.opener.location.reload();
}

</script>


</head>

<body onload='a()'>

</body>

</html>


";
?>