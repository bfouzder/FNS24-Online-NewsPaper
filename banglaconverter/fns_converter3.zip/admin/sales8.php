<html>
<head>


  <link rel="stylesheet" href="jquery-ui-themes-1.11.4/themes/smoothness/jquery-ui.css">
  
  
  
  <script src="jquery-1.10.2.js"></script>
  <script src="jquery-ui.js"></script>
  
 

<script type="text/javascript">
$(function() 
{
 $( "#coding_language" ).autocomplete({
  source: 'new.php'
 });
});
</script>
</head>
<body>
<div id="wrapper">
<div class="ui-widget">
 <p>Enter Coding Language</p>
 <input type="text" id="coding_language">
</div>

</div>
</body>
</html>