<?php
print"
<td align='center' valign='top' width='220' bgcolor='#C5B991'>  

<table align='center' width='200' cellpadding='0' cellspacing='0' height=''>

<tr> <td height='10'> </td></tr>


<tr> <td height='30' width='200' bgcolor='green'>   <div id='child'> <b> <font color='white'> Find Transaction </font> </b> </div>  </td></tr>
<tr> <td height='7'> </td></tr>

";

/*
print"
<tr> <td height='30' width='200' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" align='left' id='button2'>  <a href='supplier_transection.php' target='a_blank'> <div id='child'> Supplier Transaction </div> </a> </td></tr>
<tr> <td height='7'> </td></tr>
";
*/


if($advance100==100)
{
print"
<tr> <td height='30' width='200' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" align='left' id='button2'>  <a href='supplier_advance_transection.php' target='a_blank'> <div id='child'> Supplier Advance Ledger  </div> </a> </td></tr>
<tr> <td height='7'> </td></tr>
";
}

print"
<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='supplier_laser_transection.php' target='a_blank'><div id='child'>  Supplier Ledger  </div> </a> </td></tr>

<tr> <td height='7'> </td></tr>
";


/*
<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='customer_transection.php' target='a_blank'><div id='child'>  Customer Transaction </div> </a> </td></tr>
<tr> <td height='7'> </td></tr>
*/



if($advance100==100)
{
print"
<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='customer_advance_transection.php' target='a_blank'><div id='child'>  Customer Advance  Ledger </div> </a> </td></tr>
<tr> <td height='7'> </td></tr>
";
}


print"
<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='customer_laser_transection.php' target='a_blank'><div id='child'>  Customer Ledger  </div> </a> </td></tr>

<tr> <td height='7'> </td></tr>


";


print"
<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='bill_laser_transection.php' target='a_blank'><div id='child'>  Bill Collection  Ledger  </div> </a> </td></tr>

<tr> <td height='7'> </td></tr>



<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='due_bill.php' target='a_blank'><div id='child'>  Find Due Bill </div> </a> </td></tr>

<tr> <td height='7'> </td></tr>


<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='party_due_bill.php' target='a_blank'><div id='child'>  Find Customer Due Bill </div> </a> </td></tr>
<tr> <td height='7'> </td></tr>

";








print"
<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='payment_laser_transection.php' target='a_blank'><div id='child'>  Bill Payment  Ledger  </div> </a> </td></tr>

<tr> <td height='7'> </td></tr>



<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='due_payment.php' target='a_blank'><div id='child'>  Find Due Payment </div> </a> </td></tr>

<tr> <td height='7'> </td></tr>








<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='party_due_payment.php' target='a_blank'><div id='child'>  Find Supplier Due Payment </div> </a> </td></tr>

<tr> <td height='7'> </td></tr>


";

























print"
<tr> <td height='30' width='200'  align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='payment_transection.php' target='a_blank'> <div id='child'> Payment Ledger [office]  </div> </a> </td></tr>

<tr> <td height='7'> </td></tr>
";



print"
<tr> <td height='30' width='200'  align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='payment_transection_other.php' target='a_blank'> <div id='child'> Payment Ledger [Others] </div> </a> </td></tr>

<tr> <td height='7'> </td></tr>
";




print"
<tr> <td height='30' width='200'  align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='rpayment_transection.php' target='a_blank'> <div id='child'> Others Income Ledger  </div> </a> </td></tr>
<tr> <td height='7'> </td></tr>
";


print"
<tr> <td height='30' width='200'  align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='bank_transection.php'> <div id='child'> Bank Ledger </div> </a> </td></tr>

<tr> <td height='7'> </td></tr>






<tr> <td height='30' width='200'  align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='view_profile.php'target='_blank'> <div id='child'> View Employee Profile </div> </a> </td></tr>

<tr> <td height='7'> </td></tr>


<tr> <td height='30' width='200'  align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='pf_transection.php'> <div id='child'>   PF Transaction </div> </a> </td></tr>

<tr> <td height='7'> </td></tr>




</table>


</td>
";
?>