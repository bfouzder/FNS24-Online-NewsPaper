<?php


if($user_name1=="superadmin" || $pas_type==1)
{
	
	
	if($g_1==1)
	{
print"
<tr> <td bgcolor='C5B577' align='left' id='button2' height='30' onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\"> 
<a href='create_godawn.php'>
<div id='child'>  Create Branch / Godawn  </div> </a>  </td></tr>
<tr> <td height='7'> </td></tr>



<tr> <td bgcolor='C5B577' align='left' id='button2' height='30' onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\"> 
<a href='transfer.php'>
<div id='child'>  Transfer </div> </a>  </td></tr>
<tr> <td height='7'> </td></tr>
";

	}



print"

<tr> <td bgcolor='C5B577' align='left' id='button2' height='30' onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\"> 
<a href='product_category.php'>
<div id='child'>  New Product Category  </div> </a>  </td></tr>
<tr> <td height='7'> </td></tr>





<tr> <td height='30' width='200' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" align='left' id='button2'>  <a href='product_sub_category.php'> <div id='child'> New Product Sub Category </div> </a> </td></tr>

<tr> <td height='7'> </td></tr>


<tr> <td height='30' width='200' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" align='left' id='button2'>  <a href='product_type.php'> <div id='child'>  New Product Unit Name </div> </a> </td></tr>

<tr> <td height='7'> </td></tr>


<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='product_name.php'><div id='child'>  New Product Name         </div> </a> </td></tr>

<tr> <td height='7'> </td></tr>
";


print"
<tr> <td height='30' width='200'  align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='create_area.php'> <div id='child'>  New Area Name </div> </a> </td></tr>
<tr> <td height='7'> </td></tr>
";



print"
<tr> <td height='30' width='200'  align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='customer.php'> <div id='child'>  New Customer Name  </div> </a> </td></tr>
<tr> <td height='7'> </td></tr>
";



print"
<tr> <td height='30' width='200'  align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='contact.php'> <div id='child'> New Sales Person  </div> </a> </td></tr>
<tr> <td height='7'> </td></tr>
";


print"
<tr> <td height='30' width='200'  align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='contact1.php'> <div id='child'> New Receiver Person  </div> </a> </td></tr>
<tr> <td height='7'> </td></tr>
";




}


if($pas_type==2)
{
print"
<tr> <td height='30' width='200'  align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='customer.php'> <div id='child'>  New Customer Name  </div> </a> </td></tr>
<tr> <td height='7'> </td></tr>
";
}




if($user_name1=="superadmin" || $pas_type==1)
{

print"
<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='supplier.php'> <div id='child'>  New Supplier Name  </div> </a> </td></tr>
<tr> <td height='7'> </td></tr>



<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='payment_laser.php'> <div id='child'>  New Payment Ledger </div> </a> </td></tr>

<tr> <td height='7'> </td></tr>








<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='expendature_head.php'> <div id='child'>  New Expenditure Head </div> </a> </td></tr>

<tr> <td height='7'> </td></tr>



<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='expendature_sub.php'> <div id='child'>  New Expenditure Sub Head </div> </a></td></tr>

<tr> <td height='7'> </td></tr>

";




print"

<tr> <td height='30' width='200'  align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='receipt_laser.php'> <div id='child'> Others Income  Ledger </div> </a> </td></tr>

<tr> <td height='7'> </td></tr>


<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='rexpendature_head.php'> <div id='child'> Receipt Collection Head </div> </a> </td></tr>

<tr> <td height='7'> </td></tr>



<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='rexpendature_sub.php'> <div id='child'> Receipt Collection. Sub Head </div> </a></td></tr>

<tr> <td height='7'> </td></tr>

";







print"

<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='asset.php'> <div id='child'>  Asset Entry </div> </a></td></tr>
<tr> <td height='7'> </td></tr>


<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='capital.php'> <div id='child'> For Capital Graph </div> </a></td></tr>
<tr> <td height='7'> </td></tr>
";

if($s_sheet==1)
{
print"
<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='employee_entry.php'> <div id='child'>  New Employee Profile </div> </a></td></tr>
<tr> <td height='7'> </td></tr>

<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='salary_sheet.php' target='_blank'> <div id='child'>  New Salary Sheet </div> </a></td></tr>
<tr> <td height='7'> </td></tr>



";
}




/*


<tr> <td height='30' width='200'  align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='receipt_laser.php'> <div id='child'> Receipt Ledger </div> </a> </td></tr>

<tr> <td height='7'> </td></tr>


<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='rexpendature_head.php'> <div id='child'> Receipt Collection Head </div> </a> </td></tr>

<tr> <td height='7'> </td></tr>



<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='rexpendature_sub.php'> <div id='child'> Receipt Colle. Sub Head </div> </a></td></tr>

<tr> <td height='7'> </td></tr>
*/







print"
<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='bank.php'> <div id='child'>  New Bank Account </div> </a></td></tr>
<tr> <td height='7'> </td></tr>
";

}


if($user_name1=="superadmin")
{
print"
<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='create_password.php'> <div id='child'> New Account </div> </a></td></tr>

<tr> <td height='3'> </td></tr>
";

}



print"

</table>


</td>
";

?>