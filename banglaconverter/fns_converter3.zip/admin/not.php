
<?php

print"

<html>

<head>

<script language='javascript'>


function a()

{

alert( 'Not enough balance ');



}

</script>


</head>

<body onload='a()'>

</body>

</html>


";
?>