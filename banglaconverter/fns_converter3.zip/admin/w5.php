<?php

print"

<html>

<head>

<script language='javascript'>


function a()

{

alert( ' Please write correct ');

}

</script>


</head>

<body onload='a()'>

</body>

</html>


";
?>