<?php
print"

<tr> <td height='0'> </td></tr>


<tr> <td height='30' width='240' bgcolor='green'> &nbsp;&nbsp;&nbsp;  <span id='child'> <b> <font color='white'> Stock Issu  </font> </b> </span>  </td></tr>

<tr> <td height='7'> </td></tr>


<tr> <td height='30' width='200' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" align='left' id='button2'> <a href='transfer.php'> <div id='child'> Godawn To Godawn Transfer </div> </a> </td></tr>

<tr> <td height='7'> </td></tr>


<tr> <td height='30' width='200' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" align='left' id='button2'> <a href='product_to_product.php'> <div id='child'> Product To Product Transfer </div> </a> </td></tr>

<tr> <td height='7'> </td></tr>


<tr> <td height='30' width='200' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" align='left' id='button2'> <a href='stock_in.php'> <div id='child'> Stock In </div> </a> </td></tr>

<tr> <td height='7'> </td></tr>



<tr> <td height='30' width='200' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" align='left' id='button2'> <a href='stock_out.php'> <div id='child'> Stock Out </div> </a> </td></tr>

<tr> <td height='7'> </td></tr>


";

?>