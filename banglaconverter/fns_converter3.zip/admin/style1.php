<?php

print"

<meta http-equiv='content-type' content='text/html;charset=utf-8' />



<style>


body
{
margin-top:0px;
}


#kh
{
border-radius:$set_radius;
font-family:arial;
font-size:$set_font_size;
color:$set_font_color;
}





#bangla
{
width:100px;
height:20px;
font-family:arial;
font-size:15px;
}


#sup
{
width:100px;
height:20px;
font-family:arial;
font-size:15px;
}



#q
{
    FONT-WEIGHT: bold; FONT-SIZE: 10px; BACKGROUND: url(images/topback.jpg); COLOR: black; FONT-STYLE: normal; FONT-FAMILY: verdana, Arial, Helvetica, sans-serif
}


#q1
{
    FONT-WEIGHT: normal; FONT-SIZE: 10px; BACKGROUND: url(images/topback.jpg); COLOR: black; FONT-STYLE: normal; FONT-FAMILY: verdana, Arial, Helvetica, sans-serif
}




#lll
{
    FONT-WEIGHT:bold; FONT-SIZE: 13px; BACKGROUND: url(images/topback.jpg); COLOR:red; FONT-STYLE: normal; FONT-FAMILY: verdana, Arial, Helvetica, sans-serif
}


A:link {
    FONT-WEIGHT: normal; FONT-SIZE: 13px; COLOR: white; FONT-STYLE: normal; FONT-FAMILY: verdana, Arial, Helvetica, sans-serif; TEXT-DECORATION: none
}

A:visited {
    FONT-WEIGHT: normal; FONT-SIZE: 13px; COLOR: white; FONT-STYLE: normal; FONT-FAMILY: verdana, Arial, Helvetica, sans-serif; TEXT-DECORATION: none
}
A:active {
    FONT-WEIGHT: normal; FONT-SIZE: 13px; COLOR: White; FONT-STYLE: normal; FONT-FAMILY: verdana, Arial, Helvetica, sans-serif; TEXT-DECORATION: none
}
A:hover {
    FONT-WEIGHT: normal; FONT-SIZE: 13px; COLOR: red; FONT-STYLE: normal; FONT-FAMILY: verdana, Arial, Helvetica, sans-serif; TEXT-DECORATION: none
}






#q9
{
margin-left:11px;
}



.llink {
    FONT-WEIGHT: normal; FONT-SIZE: 12px; WIDTH: 100%; COLOR: #000000; FONT-FAMILY: Boishakhi
}
A.l:active {
    FONT-WEIGHT: normal; FONT-SIZE: 12px; BACKGROUND: url(images/topback.jpg); COLOR: black; FONT-STYLE: normal; FONT-FAMILY: verdana, Arial, Helvetica, sans-serif
}
A.l:link {
    FONT-WEIGHT: normal; FONT-SIZE: 12px; BACKGROUND: url(images/topback.jpg); COLOR: black; FONT-STYLE: normal; FONT-FAMILY: verdana, Arial, Helvetica, sans-serif
}
A.l:visited {
    FONT-WEIGHT: normal; FONT-SIZE: 12px; BACKGROUND: url(images/topback.jpg); COLOR: black; FONT-STYLE: normal; FONT-FAMILY: verdana, Arial, Helvetica, sans-serif
}


A.l:hover {
    FONT-WEIGHT:  normal;  FONT-SIZE: 12px; BACKGROUND: url(link.jpg) no-repeat center top;  COLOR: 606266; FONT-STYLE: normal; FONT-FAMILY: verdana, Arial, Helvetica, sans-serif; TEXT-DECORATION: none
}





.u1link {
    FONT-WEIGHT: normal; FONT-SIZE: 11px; WIDTH: 100%; COLOR: white; FONT-FAMILY: Boishakhi
}
A.u1:active {
    FONT-WEIGHT: normal; FONT-SIZE: 11px; BACKGROUND: url(images/topback.jpg); COLOR: white; FONT-STYLE: normal; FONT-FAMILY: verdana, Arial, Helvetica, sans-serif
}
A.u1:link {
    FONT-WEIGHT: normal; FONT-SIZE: 11px; BACKGROUND: url(images/topback.jpg); COLOR: white; FONT-STYLE: normal; FONT-FAMILY: verdana, Arial, Helvetica, sans-serif
}
A.u1:visited {
    FONT-WEIGHT: normal; FONT-SIZE: 11px; BACKGROUND: url(images/topback.jpg); COLOR: white; FONT-STYLE: normal; FONT-FAMILY: verdana, Arial, Helvetica, sans-serif
}


A.u1:hover {
    FONT-WEIGHT:  normal;  FONT-SIZE: 11px; BACKGROUND: url(link.jpg) no-repeat center top;  COLOR: E2DCDC; FONT-STYLE: normal; FONT-FAMILY: verdana, Arial, Helvetica, sans-serif; TEXT-DECORATION: none
}






#qqq
{
    FONT-WEIGHT: bold; FONT-SIZE: 13px; BACKGROUND: url(images/topback.jpg); COLOR: black; FONT-STYLE: normal; FONT-FAMILY: verdana, Arial, Helvetica, sans-serif
}



#an
{
font-size:12px;
}


#wq
{

font-size:11px;
FONT-WEIGHT: normal;

}


#m
{
font-family:arial;
font-size:15px;
color:white;
}







</style>








<LINK 
href='my/mvc.css' type=text/css rel=stylesheet>

<LINK href='my/system.css' type=text/css rel=stylesheet>

<LINK 
href='my/template.css' type=text/css rel=stylesheet><!--[if lte IE 6]><LINK href='my/ie6.css' 
type=text/css rel=stylesheet><![endif]-->
<LINK 
href='my/ja.moomenu.css' type=text/css rel=stylesheet>

<SCRIPT language=javascript src='my/ja.moomenu.js' 
type=text/javascript></SCRIPT>

<SCRIPT src='my/mootools.js' type=text/javascript></SCRIPT>

<SCRIPT src='my/caption.js' type=text/javascript></SCRIPT>

<LINK href='my/template2.css' type=text/css 
rel=stylesheet>
















";





?>