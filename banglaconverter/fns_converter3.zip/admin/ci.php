
<?php

print"

<html>

<head>

<script language='javascript'>


function a()

{

alert( ' Not Save exist write another customer id ');

}

</script>


</head>

<body onload='a()'>

</body>

</html>


";
?>