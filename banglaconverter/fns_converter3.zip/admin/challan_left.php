<?php



print"
<tr> <td height='30' width='200' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" align='left' id='button2'>  <a href='challan.php'> <div id='child'> Challan Invoice </div> </a> </td></tr>
<tr> <td height='7'> </td></tr>
";



print"
<tr> <td height='30' width='200' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" align='left' id='button2'>  <a href='challan_view.php' target='blank'> <div id='child'> All Challan View </div> </a> </td></tr>
<tr> <td height='7'> </td></tr>
";






print"
</table>


</td>
";

?>