<?php

print"

<html>

<head>

<script language='javascript'>


function a()

{

alert( ' Please select customer ');

}

</script>


</head>

<body onload='a()'>

</body>

</html>


";
?>