<?php
print"
<td align='center' valign='top' width='220' bgcolor='#C5B991'>  
<table align='center' width='200' cellpadding='0' cellspacing='0' height=''>
<tr> <td height='10'> </td></tr>


<tr> <td height='30' width='200' bgcolor='green'>   <div id='child'> <b> <font color='white'> Inventory  </font> </b> </div>  </td></tr>
<tr> <td height='7'> </td></tr>
";





	
print"
<tr> <td height='7'> </td></tr>
<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='sd_list.php' target='_blank'><div id='child'> Product Search  </div> </a> </td></tr>
<tr> <td height='7'> </td></tr>
";





print"
<tr> <td height='7'> </td></tr>
<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='only.php' target='_blank'><div id='child'> Stock Report  </div> </a> </td></tr>
<tr> <td height='7'> </td></tr>
";

	

print"
<tr> <td height='7'> </td></tr>
<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='sd.php' target='_blank'><div id='child'> Category Wise Stock Report  </div> </a> </td></tr>
<tr> <td height='7'> </td></tr>
";


print"
<tr> <td height='7'> </td></tr>
<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='sd7.php' target='_blank'><div id='child'> Sub Category Wise Stock Report  </div> </a> </td></tr>
<tr> <td height='7'> </td></tr>
";





print"
</table>


</td>




";

?>