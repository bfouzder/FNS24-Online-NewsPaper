<?php
include_once('dbconnection.php');


print"

<html>

<head>
<title> Stock Issu </title>
";


include_once('style.php');


print"
</head>


<body>
";


include_once('header.php');


print"
<table align='center' width='1200' cellpadding='0' cellspacing='1' height='800' bgcolor='gray'>
<tr bgcolor='white'> 
<td align='center' valign='top' width='220' bgcolor='#C5B991'>  

<table align='center' width='200' cellpadding='0' cellspacing='0' height=''>

";




include_once('stock_left.php');



/*

<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" > &nbsp;&nbsp;&nbsp; <a href='#'> <span id='child'> Receipt Laser Due </span> </a> </td></tr>

<tr> <td height='7'> </td></tr>
*/

print"


</table>


</td>
















<td align='center' valign='top' width='980'>  


<br>




</td>


</tr>
</table>




</body>

</html>


";


?>