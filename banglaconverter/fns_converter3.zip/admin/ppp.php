<?php

if($user_name1=="superadmin" || $pas_type==1)
{
}

if($pas_type==2)
{
	include_once('index.php');
exit;
}



?>