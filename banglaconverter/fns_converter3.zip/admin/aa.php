<?php

print"

<html>

<head>

<script language='javascript'>


function a()

{

alert( ' Already Saved ');

}

</script>


</head>

<body onload='a()'>

</body>

</html>


";
?>