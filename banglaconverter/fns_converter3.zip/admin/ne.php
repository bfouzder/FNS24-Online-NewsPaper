<?php

print"

<html>

<head>

<script language='javascript'>


function a()

{

alert( ' Not Enough In Stock ');



}

</script>


</head>

<body onload='a()'>

</body>

</html>


";
?>