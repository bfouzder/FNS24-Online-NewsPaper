<?php

print"

<td align='center' valign='top' width='220' bgcolor='#C5B991'>  




<table align='center' width='200' cellpadding='0' cellspacing='0' height=''>

<tr> <td height='10'> </td></tr>


<tr> <td height='30' width='200' bgcolor='green'>   <div id='child'> <b> <font color='white' size='2'> Sales Commission  </font> </b> </div>  </td></tr>

<tr> <td height='7'> </td></tr>


<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='sales_commission_entry.php'> <div id='child'> Sales Commission Entry </div> </a> </td></tr>


<tr> <td height='7'> </td></tr>


<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='find_sales_commission.php'> <div id='child'> Find Sales Commission  </div> </a> </td></tr>


<tr> <td height='7'> </td></tr>








</table>


</td>
";


?>