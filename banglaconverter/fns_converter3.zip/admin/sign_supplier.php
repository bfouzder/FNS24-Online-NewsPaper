<?php

print"

<table align='center' width='1000' cellpadding='0' cellspacing='0'>
<tr>

<td width='25' height='3' align='left'> &nbsp;&nbsp; <font face='arial' size='3'>   ...................................... </font> </td> 
<td width='15' height='3' align='center'> <font face='arial' size='3'>    </font> </td> 
<td width='20' height='3' align='right'> <font face='arial' size='3'> ................................ &nbsp;&nbsp; </font>  </td> 
</tr>

</table>

<table align='center' width='1000' cellpadding='0' cellspacing='0'>
<tr>
<td width='20' height='3' align='left'> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <font face='arial' size='4'> <b>  For Supplier </b> </font> </td> 
<td width='20' height='3' align='center'> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <font face='arial' size='3'> <b> </b>  </font>  </td> 
<td width='20' height='3' align='right'> <font face='arial' size='4'> <b> For Authority </b> </font> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </td> 
</tr>
</table>

";


?>