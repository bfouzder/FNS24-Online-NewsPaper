<?php

print"

<td align='center' valign='top' width='220' bgcolor='#C5B991'>  




<table align='center' width='200' cellpadding='0' cellspacing='0' height=''>

<tr> <td height='10'> </td></tr>


<tr> <td height='30' width='200' bgcolor='green'>   <div id='child'> <b> <font color='white' size='2'> Check report  </font> </b> </div>  </td></tr>

<tr> <td height='7'> </td></tr>
<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='check_entry.php'> <div id='child'> Cheque Receive Entry </div> </a> </td></tr
<tr> <td height='7'> </td></tr>





<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='check_view.php'> <div id='child'> Cheque Receive View </div> </a> </td></tr>
<tr> <td height='7'> </td></tr>




<tr> <td height='7'> </td></tr>
<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='check_payment.php'> <div id='child'> Cheque Payment Entry </div> </a> </td></tr
<tr> <td height='7'> </td></tr>




<tr> <td height='30' width='200' align='left' id='button2' bgcolor='C5B577'  onMouseOver=\"this.bgColor='96884F'\" onMouseOut=\"this.bgColor='C5B577'\" >  <a href='check_payment_view.php'> <div id='child'> Cheque Payment View </div> </a> </td></tr>
<tr> <td height='7'> </td></tr>



</table>


</td>
";


?>