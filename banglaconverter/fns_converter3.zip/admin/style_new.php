<?php


print"
<meta http-equiv='content-type' content='text/html;charset=utf-8' />
<style>

body
{
margin:0px;
}


#txx_b_other
{
width:140px;
height:30px;
font-family:arial;

}

#gd1
{
width:100px;
height:30px;
}


#gd
{
width:60px;
height:26px;
}


#go_new
{
width:175px;
height:25px;
}





#c9
{
width:200px;
height:25px;
}

#cus11
{
width:140px;
height:25px;
font-family:arial;

}



#da
{
width:50px;
height:30px;
font-family:arial;
font-size:22px;
}


#group_new
{
font-family:arial;
font-size:22px;

}




#ye
{
width:100px;
height:30px;
font-family:arial;
font-size:22px;
}


#yee
{
width:100px;
height:32px;
font-family:arial;
font-size:22px;
}







#saa
{
background-color:pink;
width:200;
font-family:arial;
font-size:16px;
border-radius:3px;
height:40px;
}








#td5
{
background-color:#F2F2F2;
width:300;
font-family:arial;
font-size:16px;
border-radius:3px;
height:40px;
}










#category5
{
width:186px;
height:25px;
}


#category6
{
width:186px;
height:50px;
}


#p_n
{
width:200px;
height:25px;
}

#p_mode
{
width:208px;
}


#crt
{
width:56px;
}


#crt2
{
width:58px;
}





#mkk
{
width:1px;
height:1px;
border:0px;
background-color:F2F2F2;
}

#bacg
{
	

border-radius:5px;

}

#sup
{
width:200px;
}

#new_sup1
{
padding:5px;
width:200px;
height:25px;


}

#tx
{
padding:5px;
width:200px;
height:14px;
}

#pr
{
padding:5px;
width:120px;
height:36px;
}


#pr3
{
padding:5px;
width:120px;
height:36px;
background-color:yellow;
}




#pr2
{
padding:5px;
width:50px;
height:26px;
}


#pr5
{
padding:5px;
width:140px;
height:26px;
}



#tx2
{
padding:5px;
width:120px;
height:16px;
}

#txx
{
padding:5px;
width:50px;
height:26px;

}



#txx_b
{
padding:5px;
width:50px;
height:26px;
}



#txx_q
{
padding:5px;
width:50px;
height:26px;

}






#tx3
{
padding:5px;
width:80px;
height:16px;
}

#tx4
{
padding:5px;
width:80px;
height:25px;
}


#txx4
{
padding:5px;
width:50px;
height:25px;
}


#txt_c
{
padding:5px;
width:178px;
height:25px;
}


#txt
{
padding:5px;
width:200px;
height:25px;
}


#txt2
{
padding:5px;
width:100px;
height:25px;
}


#txt3_in
{
padding:5px;
width:166px;
height:20px;
}


#txt2_in
{
padding:5px;
width:180px;
height:25px;
}



#p_tags
{
padding:5px;
width:745px;
height:28px;
}


#tags2_pur
{
padding:5px;
width:724px;
height:18px;
}





#text_dp
{
padding:5px;
width:724px;
height:18px;
}





#tags2_sales_p
{
padding:5px;
width:727px;
height:18px;
}


#tags2_c
{
padding:5px;
width:738px;
height:25px;
}


#tags2_sales
{
padding:5px;
width:738px;
height:25px;
}


#text_d_p
{
padding:5px;
width:727px;
height:18px;
}





#text_d
{
padding:5px;
width:738px;
height:25px;
}


#text_mobile
{
padding:5px;
width:332px;
height:25px;
}


#text_mobile2
{
padding:5px;
width:377px;
height:25px;
}





#tags
{
padding:5px;
width:332px;
height:25px;
}


#enter
{
padding:5px;
width:80px;
height:35px;
}


#enter2
{
padding:5px;
width:120px;
height:35px;
}


#enter3
{
padding:5px;
width:150px;
height:35px;
}


#dat1
{
padding:5px;
width:50px;
height:25px;
}

#mon1
{
padding:5px;	
width:50px;
height:25px;
}

#yer1
{
padding:5px;
width:70px;
height:25px;
}





#bangla
{
width:130px;	
}


#new_sup
{
width:200px;
}




A:link {
    FONT-WEIGHT: normal; FONT-SIZE: 13px; COLOR: black; FONT-STYLE: normal; FONT-FAMILY: verdana, Arial, Helvetica, sans-serif; TEXT-DECORATION: none
}

A:visited {
    FONT-WEIGHT: normal; FONT-SIZE: 13px; COLOR: black; FONT-STYLE: normal; FONT-FAMILY: verdana, Arial, Helvetica, sans-serif; TEXT-DECORATION: none
}
A:active {
    FONT-WEIGHT: normal; FONT-SIZE: 13px; COLOR: black; FONT-STYLE: normal; FONT-FAMILY: verdana, Arial, Helvetica, sans-serif; TEXT-DECORATION: none
}
A:hover {
    FONT-WEIGHT: normal; FONT-SIZE: 13px; COLOR: black; FONT-STYLE: normal; FONT-FAMILY: verdana, Arial, Helvetica, sans-serif; TEXT-DECORATION: none
}









#button
{

border-radius:5px;	
cursor:pointer;


}








#button2
{
border:1px solid;
border-radius:5px;	
cursor:pointer;
}









#head
{
font-family:arial;
font-size:13px;
color:white;
font-weight:bold;
height:25px;
padding-top:5px;
}






#child
{
font-family:arial;
font-size:13px;
color:black;
font-weight:normal;	
width:100%;
height:25px;
padding-top:5px;
padding-left:5px;

}





#tda
{
border-top-left-radius:5px;
border-top-right-radius:5px;
}



#tdt
{
border-bottom-left-radius:5px;
border-bottom-right-radius:5px;
}

#del
{
width:50px;
height:25px;
background-color:red;
padding-top:5px;
}


#cust

{
width:120px;	
	
}

</style>








";

?>











<style>




#menutop, #menutop ul {
    margin: 0;
    padding: 0;
    list-style: none;

}

#menutop {

margin: 0px auto;
border: 0px solid #66BC51;
background: url(images/menu_bg.png) repeat-x;
border-radius: 10px;
padding-left:10px;
padding-right:10px;
}





#menutop:after {
    clear: both;
}

#menutop {
    zoom:1;
}
#menutop li {
    float: left;
    border-right: 4px solid #35973D;
    position: relative;   
	 
}

#menutop li:last-child {
    border-right: 0; 
}

#menutop a {
min-width: 55px;
float: left;
padding: 2px 20px;
color: #fff;
font-size: 10px;

text-decoration: none;

font-weight: bold;
}

#menutop .active > a {

    color: #66BC51;
    padding: 8px 16px;
	
}
#menutop li:hover > a {

    color: #fff;
	background-color:#F95050;
  
}

/*
#menutop li:hover > a {
    color: #66BC51;
	background: url(menu_bg_hover.png) repeat-x;
}
*/


*html #menutop li a:hover { /* IE6 only */
    color: #66BC51;
	
}
#menutop ul {
    margin: 20px 0 0 0;
    _margin: 0; /*IE6 only*/
    opacity: 0;
    visibility: hidden;
    position: absolute;
    top: 38px;
    left: 0;
    z-index: 99999999;    
    background: red;    
    /*background: url(images/menutop_bg.png) repeat-x;*/
    box-shadow: 0 -1px 0 rgba(255,255,255,.3);  
    border-radius: 0px;
    transition: all .2s ease-in-out;    
    min-width: 160px;
}


#menutop li:hover > ul {
    opacity: 1;
    visibility: visible;
    margin: 0; background:#DA683E;
		
}
#menutop ul ul {
    top: 0;
    left: 98%;
    margin: 0 0 0 10px;
    _margin: 0; /*IE6 only*/
    box-shadow: -1px 0 0 rgba(255,255,255,.3);   
	   
}

#menutop ul li {
    float: none;
    display: block;
    border: 0;
    _line-height: 0; /*IE6 only*/
    box-shadow: 0 1px 0 #488E37
}

#menutop ul li:last-child {   
    box-shadow: 0 1px 0 #488E37;    
}

#menutop ul a {    
    padding: 14px;
    _height: 10px; /*IE6 only*/
    display: block;
    white-space: nowrap;
    float: none;
    text-transform:capitalize;
    text-align: left;
}

#menutop ul a:hover {
    background-color: #66BC51;
    
    }
    
#menutop ul li:first-child > a {
    border-radius: 3px 3px 0 0;
}

#menutop ul li:first-child > a:after {
    content: '';
    position: absolute;
    left: 40px;
    top: -6px;
    border-left: 6px solid transparent;
    border-right: 6px solid transparent;
    border-bottom: 6px solid #444;
}

#menutop ul ul li:first-child a:after {
    left: -6px;
    top: 50%;
    margin-top: -6px;
    border-left: 0; 
    border-bottom: 6px solid transparent;
    border-top: 6px solid transparent;
    border-right: 6px solid #3b3b3b;
	
}

#menutop ul li:first-child a:hover:after {
    border-bottom-color: #3b3b3b; 
}

#menutop ul ul li:first-child a:hover:after {
    border-right-color: #3b3b3b; 
    border-bottom-color: transparent;   
}

#menutop ul li:last-child > a {
    border-radius: 0 0 3px 3px;
	
}

</style>









