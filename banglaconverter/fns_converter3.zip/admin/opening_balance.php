<?php
include_once('dbconnection.php');
print"

<html>

<head>
<title> Opening Balance Entry  </title>
";


include_once('style.php');


print"
</head>


<body>
";


include_once('header.php');


print"
<table align='center' width='1200' cellpadding='0' cellspacing='1' height='800' bgcolor='gray'>
<tr bgcolor='white'> 

";





include_once('opening_balance_left.php');









print"


<td align='center' valign='top' width='980'>  </td>


</tr>
</table>




</body>

</html>


";


?>