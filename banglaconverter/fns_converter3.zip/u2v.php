<?php
/*
require_once 'u2b.php';
$uni_text=trim($_POST['convert']);

$converted = u2b($uni_text);

print"$converted";
*/

include_once('db.php');



?>




<?php
require_once 'Unicode2Bijoy.php';


$str=trim($_POST['convert']);


/*

$str='হৃদয়ের চঞ্চলতা বন্ধে ব্রতী হলে
জীবন পরিপূর্ণ হবে নানা রঙের ফুলে।
কুঞ্ঝটিকা প্রভঞ্জন শঙ্কার কারণ
লণ্ডভণ্ড করে যায় ধরার অঙ্গন।
ক্ষিপ্ত হলে সাঙ্গ হবে বিজ্ঞজনে বলে
শান্ত হলে এ ব্রহ্মাণ্ডে বাঞ্ছিতফল মেলে।
আষাঢ়ে ঈশান কোনে হঠাৎ ঝড় উঠে
গগন মেঘেতে ঢাকে বৃষ্টি নামে মাঠে
ঊষার আকাশে নামে সন্ধ্যার ছায়া
ঐ দেখো থেমে গেছে পারাপারে খেয়া।
শরৎ ঋতুতে চাঁদ আলোয় অংশুমান
সুখ দুঃখ পাশা পাশি সহ অবস্থান।
যে জলেতে ঈশ্বর তৃষ্ণা মেটায়
সেই জলেতে জীবকুলে বিনাশ ঘটায়।
রোগ যদি দেহ ছেড়ে মনে গিয়ে ধরে
ঔষধের সাধ্য কি বা তারে সুস্থ করে ?';
*/


?>


<?php
//echo Unicode2Bijoy::convert($str);

$data_final=Unicode2Bijoy::convert($str);

//print"$data_final";


$value=$data_final;






$result = mysqli_query($con_db,"SELECT * FROM `right_word` where button='21'  ORDER BY `user_id` ASC  LIMIT 0 ,10000000000000000");

while ($a_row = mysqli_fetch_row($result)) {

	foreach ($a_row as $field) {
		
	}
	
	
	
$value=str_replace("$a_row[1]","$a_row[2]","$value");
	

}    





$data_final=$value;


print"$data_final";



?>